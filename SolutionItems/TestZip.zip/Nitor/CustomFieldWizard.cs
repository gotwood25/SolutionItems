﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCS.Automation.Core;
using VCS.Automation.Core.Selenium;
using VCS.QA.Core;

namespace VCS.Automation.VPC4PAdapters.CoreAdapter.WebDrivers.PageObjects
{
    public class CustomFieldWizard : BasePage
    {
        #region constructor

        public CustomFieldWizard(string baseUrl, SeleniumBase browserManager)
            : base(baseUrl, "CustomFields/CustomFieldWizard.aspx", browserManager)
        {
            SwitchToPage();   
        }

        #endregion

        #region Page Elements

        /// <summary>
        /// Definition of the Next field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement Next
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_cFooter_tblButtonNext")); }
        }

        /// <summary>
        /// Definition of the Finish field within the Custom Field Setup Wizard page.
        /// Different sort of Button which does not have a Disabled property so need to 
        /// check the onclick being set before returning.
        /// </summary>
        public IWebElement Finish
        {
            get 
            { 
                bool breakout = false;
                IWebElement ele = null;

                while (breakout == false)
                {
                    ele = BrowserManager.Driver.FindElement(By.Id("Wizard1_cFooter_tblButtonFinish"));

                    try
                    {
                        while (ele.GetAttribute("onclick") == string.Empty)
                        {
                            ele = BrowserManager.Driver.FindElement(By.Id("Wizard1_cFooter_tblButtonFinish"));
                        }

                        breakout = true;
                    }
                    catch (StaleElementReferenceException ex)
                    {
                        TestManager.Doc.Error(ex.Message);
                    }
  
                }

                return ele;
            }
        }

        /// <summary>
        /// Definition of the Cancel field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement Cancel
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_cFooter_tblButtonCancel")); }
        }  

        /// <summary>
        /// Definition of the Name field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement Name
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep2_HexTextBoxCFName")); }
        }

        /// <summary>
        /// Definition of the Description field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement Description
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep2_HexTextBoxCFDescription")); }
        } 

        /// <summary>
        /// Definition of the CustomFieldType field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement CustomFieldType
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep4_HexagonDropDownListCFTypes")); }
        }

        /// <summary>
        /// Definition of the CustomFieldType field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement CreateOptionList
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep4_HexagonCheckBoxSelectOptions")); }
        }

        /// <summary>
        /// Definition of the ValidationRule field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement ValidationRule
        {
            get 
            {
                IList<IWebElement> list = (BrowserManager.Driver.FindElements(By.XPath("//tr[@id='trCFValidationRule']//select")));

                foreach(IWebElement ele in list)
                {
                    if(ele.Displayed)
                    {
                        return ele;
                    }
                }

                return null;
            }
        }

        /// <summary>
        /// Definition of the MaxLength field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement MaxLength
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep4_HexagontextboxMaxLength")); }
        }

        /// <summary>
        /// Definition of the MaxLength field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement MinLength
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep4_HexagontextboxMinLength")); }
        }

        /// <summary>
        /// Definition of the InputMethod field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement InputMethod
        {
            get
            {
                IList<IWebElement> list = (BrowserManager.Driver.FindElements(By.XPath("//tr[@id='trInputMethod']//select")));

                foreach (IWebElement ele in list)
                {
                    if (ele.Displayed)
                    {
                        return ele;
                    }
                }

                return null;
            }
        }

        /// <summary>
        /// Definition of the Mandatory field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement Mandatory
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep4_HexagonCheckBoxMandatory")); }
        }

        /// <summary>
        /// Definition of the UseDefault field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement UseDefault
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep5_HexCheckBoxUseAsDefault")); }
        }
            
        /// <summary>
        /// Definition of the DefaultStringValue field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement DefaultStringValue
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1$WizardStep5$CustomFieldPreview$HexTextBoxValue")); }
        }    
        
        /// <summary>
        /// Definition of the DefaultIntValue field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement DefaultIntValue
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep5_CustomFieldPreview_HexTextBoxValue")); }
        }  
        
        /// <summary>
        /// Definition of the DefaultIntValue field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement DefaultDateValue
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep5_CustomFieldPreview_dpDate_dtPkr_dateInput_text")); }
        }

        /// <summary>
        /// Definition of the DefaultCheckBox field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement DefaultCheckBox
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep5_CustomFieldPreview_HexCheckBoxValue")); }
        }

        /// <summary>
        /// Definition of the DefaultRadioButtonTrue field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement DefaultRadioButtonTrue
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep5_CustomFieldPreview_HexRadioButtonListValue_0")); }
        }

        /// <summary>
        /// Definition of the DefaultRadioButtonFalse field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement DefaultRadioButtonFalse
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep5_CustomFieldPreview_HexRadioButtonListValue_1")); }
        }  
        
        /// <summary>
        /// Definition of the SetDefaultDate field within the Custom Field Setup Wizard page.
        /// </summary>
        public IWebElement SetDefaultDate
        {
            get { return BrowserManager.Driver.FindElement(By.Id("Wizard1_WizardStep5_HexagonCheckBoxSetDefaultToNow")); }
        }

        #endregion
    }
}
