﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCS.Automation.Core;
using VCS.Automation.Core.Selenium;
using VCS.QA.Core;

namespace VCS.Automation.VPC4PAdapters.CoreAdapter.WebDrivers.PageObjects
{
    public class WorkAreaFrame : BasePage
    {
        #region constructor

        public WorkAreaFrame(string baseUrl, SeleniumBase browserManager)
            : base(baseUrl, "Default.aspx", browserManager)
        {
            SwitchToPage();

            while (true)
            {
                try
                {
                    //Wait for Frame

                    System.Threading.Thread.Sleep(500);

                    WebDriverWait wait = new WebDriverWait(BrowserManager.Driver, new TimeSpan(0, 0, 1));
                    wait.Until(ExpectedConditions.ElementExists(By.Id("workarea")));
                    browserManager.Driver.SwitchTo().Frame(browserManager.Driver.FindElement(By.Id("workarea")));
                    break;

                }
                catch (StaleElementReferenceException stEx) { }//Ignore this exception type
                catch(Exception ex)
                {
                    TestManager.Doc.Error("Error Switching to Frame: Work Area");
                    throw;
                }
            }
        }

        #endregion

        #region page element definitions

        public IWebElement SearchByName
        {
            get
            {
                //return BrowserManager.Driver.FindElement(By.Id("DocumentName"));
                return BrowserManager.Driver.FindElement(By.XPath("//input[@onblur='return ValidationName();']"));
            }
        }

        public IWebElement SearchButton
        {
            get
            {
                return BrowserManager.Driver.FindElement(By.Id("btnSearch"));
            }
        }
        
        #region Work Area Task Bar

        public IWebElement Items
        {
            get
            {
                IWebElement ele = null;

                while (true)
                {

                    try
                    {
                        BrowserManager.Driver.SwitchTo().DefaultContent();
                        BrowserManager.Driver.SwitchTo().Frame(BrowserManager.Driver.FindElement(By.Id("workarea")));
                        ele = BrowserManager.Driver.FindElement(By.Id("schPnl_cRadTabStrip_tabHide"));
                        break;
                    }
                    catch (StaleElementReferenceException stEx) { } //Ignore Exception
                    catch (NoSuchElementException ex) { break; }
                }    
                
                return ele;    
            }

        }

        public IWebElement Search
        {
            get
            {
                BrowserManager.Driver.SwitchTo().DefaultContent();
                BrowserManager.Driver.SwitchTo().Frame(BrowserManager.Driver.FindElement(By.Id("workarea")));
                return BrowserManager.Driver.FindElement(By.Id("schPnl_cRadTabStrip_tabStandard"));
            }

        }

        #endregion

        #region Security Group Page Controls

        public IWebElement AddSecurityGroup
        {
            get
            {
                return BrowserManager.Driver.FindElement(By.XPath("//a[@title='Add New Security Group']"));
            }
        }

        #endregion 

        #region Grid Menu Controls

        public IWebElement Edit
        {
            get
            {
                System.Threading.Thread.Sleep(500);
                BrowserManager.Wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//span[text()='Edit']")));
                return BrowserManager.Driver.FindElement(By.XPath("//span[text()='Edit']"));
            }
        }

        public IWebElement ReviseItem
        {
            get
            {
                System.Threading.Thread.Sleep(500);
                BrowserManager.Wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//span[text()='Revise Item']")));
                return BrowserManager.Driver.FindElement(By.XPath("//span[text()='Revise Item']"));
            }
        }

        public IWebElement ActivityLog
        {
            get
            {
                System.Threading.Thread.Sleep(500);
                BrowserManager.Wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//span[text()='Activity Log']")));
                return BrowserManager.Driver.FindElement(By.XPath("//span[text()='Activity Log']"));
            }
        }

        #endregion

        public IWebElement ReviseItems
        {
            get
            {
                return BrowserManager.Driver.FindElement(By.XPath("//span[text()='Revise Item(s)']"));
            }
        }

        public IWebElement RecordsPerPage
        {
            get
            {
                return BrowserManager.Driver.FindElement(By.Id("resLst_ListViewControl_NavBar_cChooseNumber"));
            }
        }

        public IWebElement LoadingControl
        {
            get
            {
                try
                {
                    return BrowserManager.Driver.FindElement(By.Id("//*[@id='resLst_ListViewControl_RadAjaxLoadingPanelresLst_ListViewControl_updatePanel']"));
                }
                catch(Exception ex)
                {
                    Log.Error(ex.ToString());
                    return null;
                }
            
            }

        }

        #endregion

    }
}
