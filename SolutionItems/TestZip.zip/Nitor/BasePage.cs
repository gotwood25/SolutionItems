﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCS.Automation.Core.Selenium
{
    /// <summary>
    /// Definition of the base page Selenium PageObject
    /// </summary>
    /// <remarks>
    /// <list type="bullet">
    /// <item>Defines the 'chrome' portion of the page (top nav bar)</item>
    /// <item>Navigation functionality</item>
    /// <item>Logout functionality</item>
    /// </list>
    /// </remarks>
    public abstract class BasePage 
    {
        #region Accessors and Variables
        public SeleniumBase BrowserManager { get; set; }

        public string BaseUrl { get; set; }
        public string BasePageUrl { get; set; }

        #endregion

        #region Constructor and Destructor

        public BasePage(string baseUrl, string basePageUrl, SeleniumBase browserManager)
        {
            BaseUrl = baseUrl;
            BasePageUrl = basePageUrl;
            BrowserManager = browserManager;
        }
        
        #endregion

        #region Base Implementation

        /// <summary>
        /// Returns the target URL of a specified page.
        /// </summary>
        public virtual string PageUrl
        {
            get
            {
                // TODO Implement a better combine method (likely using Uri)
                return BaseUrl + BasePageUrl;
            }
        }

        /// <summary>
        /// Implements navigation to the page.
        /// </summary>
        /// <remarks>
        /// Expects the site to already be authenticated.
        /// </remarks>
        /// <returns></returns>
        public virtual bool NavigateTo()
        {
            bool ret = false;

            try
            {
                BrowserManager.Driver.Navigate().GoToUrl(PageUrl);
                ret = IsPageLoaded();
            }
            catch(NoSuchElementException){/*Swallow this exception and return false */}
            catch (Exception) { throw; }
            
            return ret;
        }

        /// <summary>
        /// Wait For Window to Close - Waits for the page to close and returns, or timesout after 30 seconds.
        /// Rather than throwing an exception in event of a timeout it returns and allows the test to continue 'ungraciously'.
        /// </summary>
        public virtual void WaitForWindowToClose()
        {

            int i = 0;

            while(IsPageLoaded())
            {
                System.Threading.Thread.Sleep(1000);
                i++;

                if(i == 10)
                {
                    break;
                }
            }
        }

        public virtual bool IsPageLoaded()
        {
            bool ret = false;

            IList<string> handles = BrowserManager.Driver.WindowHandles;

            try
            {
                foreach (string handle in handles)
                {
                    if (BrowserManager.Driver.SwitchTo().Window(handle).Url.Contains(PageUrl))
                    {
                        ret = true;
                    }
                }
            }
            catch (NoSuchWindowException nswEx)
            {
                TestManager.Doc.Peek("Window", PageUrl + " has closed during check.");
                System.Threading.Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                TestManager.Doc.Error(ex.Message);
                TestManager.Doc.Peek("Window", PageUrl + " has closed during check.");
                System.Threading.Thread.Sleep(1000);
            }

            return ret;
        }

        /// <summary>
        /// Implements method to Switch the Driver to the appropriate page.
        /// Handy for when your application has multiple pop-ups
        /// </summary>
        /// <remarks>
        /// Will attempt to switch for 5 times before returning. There are occasions when
        /// this method will be called but page won't be available so need to handle gracefully
        /// and simply log this.
        /// </remarks>
        /// <returns></returns>
        public void SwitchToPage()
        {

            bool breakout = false;
            string requiredHandle = string.Empty;
            int i = 0;
            while (breakout == false)
            {
                try
                {
                    System.Threading.Thread.Sleep(500);

                    IList<string> handles = BrowserManager.Driver.WindowHandles;

                    foreach (string handle in handles)
                    {
                        if (BrowserManager.Driver.SwitchTo().Window(handle).Url.Contains(PageUrl))
                        {
                            requiredHandle = handle;
                            breakout = true;
                        }

                        System.Threading.Thread.Sleep(100);
                    }

                    //Set SwitchTo after iteration through all handles to finally set it
                    if (requiredHandle != string.Empty)
                    {
                        BrowserManager.Driver.SwitchTo().Window(requiredHandle);
                        BrowserManager.Driver.SwitchTo().DefaultContent();
                    }

                    i++;
                    
                    //Attempt 10 iterations to allow page to load, log that page couldn't be loaded.
                    if (i >= 10 && breakout == false)
                    {
                        TestManager.Doc.Check("Unable to switch page " + PageUrl + ".");
                        breakout = true;
                    }
                }
                catch(Exception ex)
                {
                    TestManager.Doc.Error("Error switching page " + PageUrl + ". Retry");
                    throw;
                }
            }
        }

        #endregion
    }
}
