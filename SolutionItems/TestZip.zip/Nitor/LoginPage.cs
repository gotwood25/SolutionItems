﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCS.Automation.Core.Selenium;

namespace VCS.Automation.VPC4PAdapters.CoreAdapter.WebDrivers.PageObjects
{

    /// <summary>
    /// Definition of the login page Selenium PageObject
    /// </summary>
    public class LoginPage : BasePage
    {
        #region constructor

        public LoginPage(string baseUrl, SeleniumBase browserManager)
            : base(baseUrl, "PreApp/Login.aspx", browserManager)
        {

            SwitchToPage();
        }

        #endregion

        #region page element definitions

        /// <summary>
        /// Definition of the username Selenium text field element.
        /// </summary>
        public IWebElement Username
        {
            get { return BrowserManager.Driver.FindElement(By.Id("LoginBox1_txtLogin")); }
        }

        /// <summary>
        /// Definition of the password Selenium text field element.
        /// </summary>
        public IWebElement Password
        {
            get { return BrowserManager.Driver.FindElement(By.Id("LoginBox1_txtPassword")); }
        }

        /// <summary>
        /// Definition of the signIn Selenium button element.
        /// </summary>
        public IWebElement SignIn
        {
            get { return BrowserManager.Driver.FindElement(By.Name("LoginBox1$btnLogin")); }
        }

        #endregion


    }
}

